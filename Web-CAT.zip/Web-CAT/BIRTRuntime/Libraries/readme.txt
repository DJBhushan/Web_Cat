Download the BIRT runtime from its source on the web
(http://eclipse.org/birt/) and move the contents of the
ReportEngine/lib directory into this folder.