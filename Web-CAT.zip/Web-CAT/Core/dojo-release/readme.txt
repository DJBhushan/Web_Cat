
***
CURRENT DOJO VERSION:  Dojo 1.5.1
***
IMPORTANT NOTE:
If you update the Dojo version, you MUST go through the classes in the webcat
package and make sure that they are updated based on the latest code, because
some of the classes are copy-and-paste jobs from Dojo components in order to
get around behavior that we want to change.
***

Download the Dojo source release indicated above and merge it into this
directory. That is, copy its "dijit", "dojo", "dojox", and "util" directories
into this directory.

DO MAKE SURE you've downloaded a source release, which is required for the
"util" directory, as indicated by the filename:

dojo-release-x.x.x-src.(tar.gz|zip)
