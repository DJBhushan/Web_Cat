package net.sf.webcat.core;

@Deprecated
public class DatabaseAuthenticator
    extends org.webcat.core.DatabaseAuthenticator
{
    // Nothing added; exists for backwards-compatibility purposes.
}
