package net.sf.webcat.core;

@Deprecated
public class EdAuthAuthenticator extends org.webcat.core.EdAuthAuthenticator
{
    // Nothing added; exists for backwards-compatibility purposes.
}
