package net.sf.webcat.core;

@Deprecated
public class LdapAuthenticator extends org.webcat.core.LdapAuthenticator
{
    // Nothing added; exists for backwards-compatibility purposes.
}
